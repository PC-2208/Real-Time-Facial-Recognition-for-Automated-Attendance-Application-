import streamlit as st
import cv2
import os
import numpy as np
import time
import datetime
from deepface import DeepFace
from mtcnn import MTCNN
import tensorflow as tf

#  Initialize session state variables
if "page" not in st.session_state:
    st.session_state.page = "Login"
if "attendance_data" not in st.session_state:
    st.session_state.attendance_data = []
if "scanning" not in st.session_state:
    st.session_state.scanning = False
if "faculty_name" not in st.session_state:
    st.session_state.faculty_name = ""
if "subject_name" not in st.session_state:
    st.session_state.subject_name = ""
if "subject_code" not in st.session_state:
    st.session_state.subject_code = ""
if "class_time" not in st.session_state:
    st.session_state.class_time = ""
if "class_date" not in st.session_state:
    st.session_state.class_date = ""

# Define the student dataset directory
dataset_dir = r"C:\Users\user\OneDrive\Desktop\priyanshi\major project hcst\UI Development\grayscale_images"
os.makedirs(dataset_dir, exist_ok=True)

# Initialize MTCNN
detector = MTCNN()

# Function to detect face using MTCNN
def detect_face_mtcnn(image):
    results = detector.detect_faces(image)
    if len(results) > 0:
        x, y, w, h = results[0]['box']
        return x, y, w, h
    return None

# Function to capture student images
def capture_student_images(name):
    cam = cv2.VideoCapture(0)
    cam.set(3, 640)  # Width
    cam.set(4, 480)  # Height

    person_dir = os.path.join(dataset_dir, name)
    os.makedirs(person_dir, exist_ok=True)

    st.write(f"📸 Capturing images for {name}... Please look into the camera.")
    count = 0
    first_face_box = None

    while count < 50:
        ret, frame = cam.read()
        if not ret:
            st.error("Camera not working properly.")
            break

        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        if first_face_box is None:
            first_face_box = detect_face_mtcnn(frame)

        if first_face_box:
            x, y, w, h = first_face_box
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

            face = gray_frame[y:y+h, x:x+w]
            img_path = os.path.join(person_dir, f"{name}_{count}.jpg")
            cv2.imwrite(img_path, cv2.resize(face, (224, 224)))

            count += 1
            st.image(frame, channels="BGR")

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cam.release()
    cv2.destroyAllWindows()
    st.success(f"✅ Successfully captured 50 images for {name}!")

# **SCREEN 3: Face Scanning & Attendance**
if st.session_state.page == "Attendance System":
    st.title("📸 Face Recognition Attendance System")

    option = st.radio("Choose an option:", ["Start Attendance", "Register New Student"])

    if option == "Register New Student":
        student_name = st.text_input("Enter Student Name")
        if st.button("Capture Images"):
            if student_name:
                capture_student_images(student_name)
            else:
                st.error("Please enter a student name.")

    elif option == "Start Attendance":
        cap = cv2.VideoCapture(0)
        time.sleep(2)

        if not cap.isOpened():
            st.error("Camera not found. Check camera permissions.")
            st.stop()

        student_images = os.listdir("students/")
        known_students = {img.split('.')[0]: f"students/{img}" for img in student_images}

        stframe = st.empty()
        start_time = time.time()

        while time.time() - start_time < 10 and st.session_state.scanning:
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            stframe.image(frame, channels="RGB", use_container_width=True)

            temp_img_path = "temp_frame.jpg"
            cv2.imwrite(temp_img_path, frame)

            for name, img_path in known_students.items():
                try:
                    result = DeepFace.verify(temp_img_path, img_path, model_name="Facenet", enforce_detection=True)
                    if result["verified"]:
                        if name not in [entry["Name"] for entry in st.session_state.attendance_data]:
                            st.session_state.attendance_data.append({
                                "Name": name,
                                "Time": datetime.datetime.now().strftime("%H:%M:%S"),
                                "Date": datetime.datetime.now().strftime("%Y-%m-%d")
                            })
                            st.success(f"✅ Attendance Marked for {name}")
                except Exception as e:
                    st.error(f"Face recognition Error: {str(e)}")
                    continue

            time.sleep(1)

        cap.release()
        cv2.destroyAllWindows()

    if st.button("Stop Scanning"):
        st.session_state.scanning = False
        st.session_state.page = "Attendance Sheet"
